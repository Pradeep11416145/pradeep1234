package cucumber;


import io.cucumber.testng.AbstractTestNGCucumberTests;


public class Runner extends AbstractTestNGCucumberTests {

}
